const allowedRoles = new Set(['Rehber', 'Moderatör', 'Admin', 'Manager', 'Developer', 'Destek Ekibi']);
const requiredFields = ['minecraft', 'discord', 'age', 'role', 'active', 'experience', 'why', 'rule', 'team', 'rules'];
const json = (statusCode, body) => ({
  statusCode,
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  },
  body: JSON.stringify(body)
});

export const handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { ok: false, error: 'Yalnızca POST isteği kabul edilir.' });

  const origin = event.headers?.origin || event.headers?.Origin;
  const siteUrl = process.env.URL;
  if (origin && siteUrl && new URL(origin).host !== new URL(siteUrl).host) {
    return json(403, { ok: false, error: 'Bu kaynaktan gönderim kabul edilmiyor.' });
  }

  let data;
  try { data = JSON.parse(event.body || '{}'); }
  catch { return json(400, { ok: false, error: 'Form verisi okunamadı.' }); }

  for (const field of requiredFields) {
    if (typeof data[field] !== 'string' || !data[field].trim()) {
      return json(400, { ok: false, error: 'Lütfen tüm zorunlu alanları doldur.' });
    }
    if (data[field].length > 1500) return json(400, { ok: false, error: 'Bir alan izin verilenden uzun.' });
  }
  if (!allowedRoles.has(data.role)) return json(400, { ok: false, error: 'Geçersiz rol seçildi.' });
  if (data.rules !== 'Evet, kabul ediyorum.') return json(400, { ok: false, error: 'Başvurmak için sunucu kurallarını kabul etmelisin.' });

  const webhook = process.env.DISCORD_WEBHOOK_URL;
  if (!webhook) {
    console.error('DISCORD_WEBHOOK_URL ortam değişkeni eksik.');
    return json(503, { ok: false, error: 'Discord bağlantısı henüz yönetici tarafından ayarlanmadı.' });
  }

  const clean = Object.fromEntries(requiredFields.map(key => [key, String(data[key]).trim()]));
  const safe = (value, max = 1000) => value.replace(/@everyone|@here/g, '@\u200b$&').slice(0, max) || 'Belirtilmedi';
  const receivedAt = new Date().toISOString();
  const embed = {
    title: '🔷 Yeni Yetkili Başvurusu',
    color: 49151,
    fields: [
      { name: 'Minecraft', value: safe(clean.minecraft, 200), inline: true },
      { name: 'Discord', value: safe(clean.discord, 200), inline: true },
      { name: 'Yaş aralığı', value: safe(clean.age, 100), inline: true },
      { name: 'Başvurulan rol', value: safe(clean.role, 100), inline: true },
      { name: 'Günlük aktiflik', value: safe(clean.active, 150), inline: true },
      { name: 'Yetkililik deneyimi', value: safe(clean.experience), inline: false },
      { name: 'Neden VanillaSMP?', value: safe(clean.why), inline: false },
      { name: 'Kural ihlalinde yaklaşım', value: safe(clean.rule), inline: false },
      { name: 'Ekip üyesi hata yaparsa', value: safe(clean.team), inline: false }
    ],
    footer: { text: 'VanillaSMP • Yetkili Başvuru Merkezi' },
    timestamp: receivedAt
  };

  try {
    const discordResponse = await fetch(webhook, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: 'VanillaSMP Başvuru Sistemi',
        embeds: [embed],
        allowed_mentions: { parse: [] }
      })
    });
    if (!discordResponse.ok) {
      console.error('Discord webhook hata kodu:', discordResponse.status);
      return json(502, { ok: false, error: 'Discord bildirimi gönderilemedi. Yönetici webhook ayarını kontrol etmeli.' });
    }
  } catch (error) {
    console.error('Discord bildirimi gönderilemedi:', error.message);
    return json(502, { ok: false, error: 'Discord bağlantısı kurulamadı. Lütfen daha sonra tekrar dene.' });
  }

  return json(200, { ok: true });
};
